# Results

### Image: 3-way real / edited / AI (with 'uncertain') on data/sid/test

| metric | value |
|---|---|
| n | 1500 |
| coverage | 0.726 |
| accuracy_on_decided | 0.6318 |
| accuracy_counting_uncertain_as_wrong | 0.4587 |
| ai_auroc_real_vs_ai | 0.992 |
| ai_auroc_real_vs_ai_UnivFD_official_baseline | 0.4523 |
| test_set | data/sid/test |

Recall per class: {"real": 0.002, "edited": 0.56, "ai_generated": 0.814}

Confusion (truth -> predicted): {"real": {"edited": 362, "uncertain": 132, "ai_generated": 5, "real": 1}, "edited": {"uncertain": 186, "edited": 280, "ai_generated": 34}, "ai_generated": {"uncertain": 93, "ai_generated": 407}}

Edited recall by edit kind: {"sid_tampered": 0.56}

### Image: OpenFake test + our synthetic edits

| metric | value |
|---|---|
| n | 1496 |
| coverage | 0.7734 |
| accuracy_on_decided | 0.6292 |
| accuracy_counting_uncertain_as_wrong | 0.4866 |
| ai_auroc_real_vs_ai | 0.9797 |
| ai_auroc_real_vs_ai_UnivFD_official_baseline | 0.4936 |
| test_set | data/images/test |

Recall per class: {"real": 0.0, "edited": 0.7731, "ai_generated": 0.686}

### AI-image AUROC per generator

| generator | n | AUROC |
|---|---|---|
| z-image-turbo | 132 | 0.9724 |
| flux.2-klein-9b | 91 | 0.9686 |
| illustrious | 84 | 0.9992 |
| gpt-image-1.5 | 57 | 0.9953 |
| midjourney-7 | 36 | 0.9647 |
| veo-3 | 28 | 0.9818 |
| wan-video-2.5 | 12 | 0.99 |
| sora-2 | 8 | 0.989 |
| ernie-image-turbo | 8 | 0.9827 |
| recraft-v3 | 7 | 0.9068 |
| lumina-17-2-25 | 6 | 0.995 |
| seedream-v5.0 | 5 | 0.999 |

### Image AI detector: clean vs daily-life degraded

| set | AUROC | acc | ECE |
|---|---|---|---|
| train | 0.9566425078491846 | 0.8859024044672251 | 0.05704158555782698 |
| img_test | 0.9799226907630523 | 0.9103206412825652 | 0.03676283916070434 |
| img_test_clean_only | 0.9796907630522088 | 0.9098196392785571 | 0.03980751066320074 |
| img_test_degraded_only | 0.9803935742971888 | 0.9108216432865731 | 0.033718167658207926 |
| sid_test | 0.9920640000000001 | 0.961 | 0.07602317498611215 |

### Edit localizer (patch level) - synthetic_openfake

| metric | value |
|---|---|
| patch_auroc | 0.8754908154256765 |
| image_auroc_edited_vs_clean | 0.8945258947436331 |
| mean_patch_iou_on_edited | 0.23356160521507263 |
| n_test_edited | 498 |
| n_test_clean | 498 |


### Edit localizer (patch level) - sid_set

| metric | value |
|---|---|
| patch_auroc | 0.8508621703146169 |
| image_auroc_edited_vs_clean | 0.8718269999999999 |
| mean_patch_iou_on_edited | 0.2835037410259247 |
| n_test_edited | 500 |
| n_test_clean | 1000 |

### Audio - test

| metric | value |
|---|---|
| n | 217 |
| auroc | 1.0 |
| acc | 0.9954 |
| auroc_degraded | 0.9995 |

### Audio - test_unseen

| metric | value |
|---|---|
| n | 231 |
| auroc | 0.9782 |
| acc | 0.8831 |
| auroc_degraded | 0.9816 |

### Text

| metric | value |
|---|---|
| n | 800 |
| auroc | 0.8826 |
| acc | 0.855 |
| auroc_clean | 0.975 |
| auroc_attacked | 0.7574 |

Per domain: {"abstracts": 0.6679, "books": null}

Baseline roberta_openai_gpt2_detector (openai-community/roberta-base-openai-detector): AUROC 0.8143, acc 0.6975 

Baseline roberta_chatgpt_detector_hc3 (Hello-SimpleAI/chatgpt-detector-roberta): AUROC 0.6336, acc 0.6388 


### Image AI detection: ours vs official UnivFD weights (same CLIP backbone)

| model | AUROC real vs AI |
|---|---|
| UnivFD official head (ProGAN-trained) | 0.4523 |
| Ours (OpenFake-trained, daily-life augmented) | 0.992 |


### Explanations

LLM explanations passing the faithfulness check: 0.125 (n=24)

**d48ee06031dc5f1f.png** (truth: real)

```
Verdict: UNCERTAIN (the evidence is weak or conflicting), confidence 41%.
Main evidence:
- The edit localizer finds a region that looks pasted or altered, strongest in the top-right of the image (score 0.58).
- The learned detector gives a 41% probability that the whole image is AI-generated.
```

**5b90907bc61b0999.png** (truth: real)

```
Verdict: likely EDITED (a real image with altered regions), confidence 80%.
The system detected an alteration in the image due to its strong score for tampering in the bottom-left corner. Additionally, the AI-generated likelihood score from image.ai_score suggests there's a high chance the entire image could be artificial, though not confirmed beyond doubt. Lastly, the consistency of error levels and sensor noise across the image supports the conclusion that the image was likely edited and.
```

**tampered_04171.png** (truth: edited)

```
Verdict: UNCERTAIN (the evidence is weak or conflicting), confidence 69%.
Main evidence:
- The edit localizer finds a region that looks pasted or altered, strongest in the middle-centre of the image (score 0.95).
- The learned detector gives a 69% probability that the whole image is AI-generated.
```

**tampered_03930.png** (truth: edited)

```
Verdict: UNCERTAIN (the evidence is weak or conflicting), confidence 59%.
Main evidence:
- The edit localizer finds a region that looks pasted or altered, strongest in the top-right of the image (score 0.99).
- The learned detector gives a 59% probability that the whole image is AI-generated.
```

**full_synthetic_005025.png** (truth: ai_generated)

```
Verdict: likely AI-GENERATED, confidence 90%.
Main evidence:
- The learned detector gives a 90% probability that the whole image is AI-generated.
Evidence pointing the other way:
- Sensor-noise level is inconsistent between regions (score 1.00).
- The edit localizer finds a region that looks pasted or altered, strongest in the bottom-centre of the image (score 0.71).
```

**full_synthetic_003754.png** (truth: ai_generated)

```
Verdict: likely AI-GENERATED, confidence 87%.
Main evidence:
- The learned detector gives a 87% probability that the whole image is AI-generated.
Evidence pointing the other way:
- The edit localizer finds a region that looks pasted or altered, strongest in the middle-centre of the image (score 0.78).
- Error-level analysis shows a region that re-compresses differently from the rest (score 0.51).
```
